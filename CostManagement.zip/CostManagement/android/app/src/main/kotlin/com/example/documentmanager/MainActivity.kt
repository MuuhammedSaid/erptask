package com.example.documentmanager

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
