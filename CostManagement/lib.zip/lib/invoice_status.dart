import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class InvoiceStatusTrackingScreen extends StatefulWidget {
  @override
  _InvoiceStatusTrackingScreenState createState() =>
      _InvoiceStatusTrackingScreenState();
}

class _InvoiceStatusTrackingScreenState
    extends State<InvoiceStatusTrackingScreen> {
  String filterInvoiceId = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Invoice Status Tracking'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Enter Invoice ID to filter',
                border: OutlineInputBorder(),
                suffixIcon: filterInvoiceId.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.clear),
                        onPressed: () {
                          setState(() {
                            filterInvoiceId = '';
                          });
                        },
                      )
                    : null,
              ),
              onChanged: (val) {
                setState(() {
                  filterInvoiceId = val.trim();
                });
              },
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream:
                  FirebaseFirestore.instance.collection('invoices').snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('Error loading invoices'));
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Center(child: Text('No invoices found'));
                }

                final allInvoices = snapshot.data!.docs;
                final invoices = filterInvoiceId.isEmpty
                    ? allInvoices
                    : allInvoices
                        .where((doc) => doc.id
                            .toLowerCase()
                            .contains(filterInvoiceId.toLowerCase()))
                        .toList();

                if (invoices.isEmpty) {
                  return Center(child: Text('No matching invoices found'));
                }

                return ListView.builder(
                  itemCount: invoices.length,
                  itemBuilder: (context, index) {
                    final doc = invoices[index];
                    final data = doc.data()! as Map<String, dynamic>;

                    final totalAmount = (data['totalAmount'] ?? 0).toDouble();
                    final paidAmount = (data['paidAmount'] ?? 0).toDouble();
                    final remainingAmount = totalAmount - paidAmount;

                    final status = data['status'] ?? 'Unknown Status';

                    return Card(
                      margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: ListTile(
                        title: Text('Invoice ID: ${doc.id}'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                                'Total Amount: \$${totalAmount.toStringAsFixed(2)}'),
                            Text(
                                'Paid Amount: \$${paidAmount.toStringAsFixed(2)}'),
                            Text(
                                'Remaining: \$${remainingAmount.toStringAsFixed(2)}'),
                            Text('Status: $status'),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
