import 'package:documentmanager/AddInvoiceScreen.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class InvoiceSummaryReportScreen extends StatefulWidget {
  @override
  _InvoiceSummaryReportScreenState createState() =>
      _InvoiceSummaryReportScreenState();
}

class _InvoiceSummaryReportScreenState
    extends State<InvoiceSummaryReportScreen> {
  DateTimeRange? selectedDateRange;
  String selectedStatus = 'All';
  String selectedClient = 'All';
  List<String> statusOptions = ['All', 'Paid', 'Unpaid', 'Overdue'];
  List<String> clientOptions = ['All'];
  bool isLoadingClients = true;

  @override
  void initState() {
    super.initState();
    _fetchClientIds();
  }

  Future<void> _fetchClientIds() async {
    try {
      final snapshot =
          await FirebaseFirestore.instance.collection('invoices').get();

      final clients = <String>{};

      for (var doc in snapshot.docs) {
        final data = doc.data() as Map<String, dynamic>;
        final clientId = data['clientId'] ?? '';
        if (clientId.isNotEmpty) {
          clients.add(clientId);
        }
      }

      setState(() {
        clientOptions.addAll(clients.toList());
        isLoadingClients = false;
      });
    } catch (e) {
      print("Error fetching client IDs: $e");
      setState(() {
        isLoadingClients = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                DropdownButtonFormField<String>(
                  value: selectedStatus,
                  onChanged: (val) => setState(() => selectedStatus = val!),
                  decoration: InputDecoration(labelText: 'Select Status'),
                  items: statusOptions.map((status) {
                    return DropdownMenuItem(value: status, child: Text(status));
                  }).toList(),
                ),
                isLoadingClients
                    ? CircularProgressIndicator()
                    : DropdownButtonFormField<String>(
                        value: selectedClient,
                        onChanged: (val) =>
                            setState(() => selectedClient = val!),
                        decoration: InputDecoration(labelText: 'Select Client'),
                        items: clientOptions.map((client) {
                          return DropdownMenuItem(
                              value: client, child: Text(client));
                        }).toList(),
                      ),
                ElevatedButton(
                  onPressed: () async {
                    final picked = await showDateRangePicker(
                      context: context,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2030),
                    );
                    if (picked != null) {
                      setState(() => selectedDateRange = picked);
                    }
                  },
                  child: Text("Select Date Range"),
                ),
              ],
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream:
                  FirebaseFirestore.instance.collection('invoices').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData)
                  return Center(child: CircularProgressIndicator());

                final invoices = snapshot.data!.docs.where((doc) {
                  final data = doc.data() as Map<String, dynamic>;
                  final status = data['status'] ?? '';
                  final clientId = data['clientId'] ?? '';
                  final dueDate = (data['dueDate'] as Timestamp).toDate();

                  bool matchesStatus =
                      selectedStatus == 'All' || status == selectedStatus;
                  bool matchesClient =
                      selectedClient == 'All' || clientId == selectedClient;
                  bool matchesDate = selectedDateRange == null ||
                      (dueDate.isAfter(selectedDateRange!.start) &&
                          dueDate.isBefore(selectedDateRange!.end));

                  return matchesStatus && matchesClient && matchesDate;
                }).toList();

                return ListView.builder(
                  itemCount: invoices.length,
                  itemBuilder: (context, index) {
                    final doc = invoices[index];
                    final data = doc.data() as Map<String, dynamic>;

                    final total = (data['totalAmount'] ?? 0).toDouble();
                    final paid = (data['paidAmount'] ?? 0).toDouble();
                    final dueDate = (data['dueDate'] as Timestamp).toDate();
                    final clientId = data['clientId'] ?? 'Unknown';

                    String correctStatus;
                    if (paid >= total) {
                      correctStatus = "Paid";
                    } else if (dueDate.isBefore(DateTime.now())) {
                      correctStatus = "Overdue";
                    } else {
                      correctStatus = "Unpaid";
                    }

                    if (data['status'] != correctStatus) {
                      FirebaseFirestore.instance
                          .collection('invoices')
                          .doc(doc.id)
                          .update({'status': correctStatus});
                    }

                    return Card(
                      elevation: 4,
                      margin: const EdgeInsets.symmetric(
                          vertical: 8.0, horizontal: 16.0),
                      child: ListTile(
                        title: Text("Invoice ID: ${doc.id}"),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Client: $clientId"),
                            Text(
                                "Paid: \$${paid.toStringAsFixed(2)} / \$${total.toStringAsFixed(2)}"),
                            Text(
                                "Due Date: ${DateFormat.yMMMd().format(dueDate)}"),
                            Text("Status: ${correctStatus}"),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
