import 'package:documentmanager/invoice_status.dart';
import 'package:documentmanager/invoice_summary.dart';
import 'package:documentmanager/payment_history.dart';
import 'package:documentmanager/payment_logging.dart';
import 'package:documentmanager/reciept_generation.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    if (Firebase.apps.isEmpty) {
      await Firebase.initializeApp(
        options: const FirebaseOptions(
          apiKey: "AIzaSyD0MWojZWiN6GE_BkAjz1hSgANSRkTw3W4",
          authDomain: "documentmanager-8bc79.firebaseapp.com",
          projectId: "documentmanager-8bc79",
          storageBucket: "documentmanager-8bc79.firebasestorage.app",
          messagingSenderId: "75816416281",
          appId: "1:75816416281:web:a3d3b39ebdfcf29964a688",
          measurementId: "G-SZ3KBY265V",
        ),
      );
    }
  } catch (e) {
    print('Firebase initialization skipped: $e');
  }

  runApp(CostManagementApp());
}

class CostManagementApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cost Management',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: MainHome(),
    );
  }
}

class MainHome extends StatefulWidget {
  @override
  _MainHomeState createState() => _MainHomeState();
}

class _MainHomeState extends State<MainHome> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    PaymentLoggingScreen(),
    ReceiptScreen(),
    InvoiceStatusTrackingScreen(),
    PaymentHistoryLogScreen(),
    InvoiceSummaryReportScreen(),
  ];

  final List<String> _titles = [
    'Log Payment',
    'Generate Receipt',
    'Invoice Status',
    'Payment History',
    'Invoice Summary',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_titles[_currentIndex])),
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: Colors.indigo,
        unselectedItemColor: Colors.grey,
        onTap: (index) => setState(() => _currentIndex = index),
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.payment), label: 'Log'),
          BottomNavigationBarItem(icon: Icon(Icons.receipt), label: 'Receipt'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'Status'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'History'),
          BottomNavigationBarItem(
              icon: Icon(Icons.bar_chart), label: 'Summary'),
        ],
      ),
    );
  }
}
