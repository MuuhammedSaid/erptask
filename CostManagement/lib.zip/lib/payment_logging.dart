import 'package:documentmanager/AddInvoiceScreen.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart';

class PaymentLoggingScreen extends StatefulWidget {
  @override
  _PaymentLoggingScreenState createState() => _PaymentLoggingScreenState();
}

class _PaymentLoggingScreenState extends State<PaymentLoggingScreen> {
  String? selectedInvoiceId;
  final amountController = TextEditingController();
  String paymentMethod = 'Cash';
  final methods = ['Cash', 'Credit', 'Bank'];

  double totalAmount = 0.0;
  double paidAmount = 0.0;

  Future<void> logPayment() async {
    if (selectedInvoiceId == null || amountController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please select an invoice and enter amount")),
      );
      return;
    }

    final amount = double.tryParse(amountController.text);
    final remainingAmount = totalAmount - paidAmount;

    if (amount == null || amount <= 0 || amount > remainingAmount) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(
                "Enter a valid amount up to ${remainingAmount.toStringAsFixed(2)}")),
      );
      return;
    }

    final paymentData = {
      'invoiceId': selectedInvoiceId,
      'amount': amount,
      'method': paymentMethod,
      'date': Timestamp.now(),
    };

    final invoiceRef = FirebaseFirestore.instance
        .collection('invoices')
        .doc(selectedInvoiceId);

    await FirebaseFirestore.instance.runTransaction((transaction) async {
      final invoiceSnapshot = await transaction.get(invoiceRef);

      if (!invoiceSnapshot.exists) throw Exception("Invoice not found");

      final currentPaid = (invoiceSnapshot.get('paidAmount') ?? 0).toDouble();

      transaction.set(
        FirebaseFirestore.instance.collection('payments').doc(),
        paymentData,
      );

      transaction.update(invoiceRef, {
        'paidAmount': currentPaid + amount,
      });
    });

    amountController.clear();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Payment logged successfully")),
    );
  }

  Future<void> fetchInvoiceDetails(String invoiceId) async {
    final invoiceRef =
        FirebaseFirestore.instance.collection('invoices').doc(invoiceId);
    final invoiceSnapshot = await invoiceRef.get();
    if (invoiceSnapshot.exists) {
      setState(() {
        totalAmount = (invoiceSnapshot.get('totalAmount') ?? 0).toDouble();
        paidAmount = (invoiceSnapshot.get('paidAmount') ?? 0).toDouble();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Payment Logging')),
      body: FutureBuilder<QuerySnapshot>(
        future: FirebaseFirestore.instance.collection('invoices').get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData)
            return Center(child: CircularProgressIndicator());

          final invoices = snapshot.data!.docs;

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                // Invoice Dropdown
                DropdownButtonFormField<String>(
                  decoration: InputDecoration(labelText: 'Select Invoice'),
                  value: selectedInvoiceId,
                  items: invoices.map((doc) {
                    final clientname = doc.id;
                    return DropdownMenuItem(
                      value: doc.id,
                      child: Text('Invoice: $clientname'),
                    );
                  }).toList(),
                  onChanged: (val) {
                    setState(() {
                      selectedInvoiceId = val;
                      fetchInvoiceDetails(
                          val!); // Fetch details when invoice is selected
                    });
                  },
                ),

                // Payment Amount TextField
                TextField(
                  controller: amountController,
                  decoration: InputDecoration(labelText: 'Payment Amount'),
                  keyboardType: TextInputType.number,
                ),

                // Payment Method Dropdown
                DropdownButtonFormField<String>(
                  decoration: InputDecoration(labelText: 'Payment Method'),
                  value: paymentMethod,
                  items: methods.map((method) {
                    return DropdownMenuItem(
                      value: method,
                      child: Text(method),
                    );
                  }).toList(),
                  onChanged: (val) => setState(() => paymentMethod = val!),
                ),

                SizedBox(height: 20),

                // Log Payment Button
                ElevatedButton(
                  onPressed: logPayment,
                  child: Text("Log Payment"),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => AddInvoiceScreen()),
          );
        },
        child: Icon(Icons.add),
        tooltip: 'Add Invoice',
      ),
    );
  }
}
